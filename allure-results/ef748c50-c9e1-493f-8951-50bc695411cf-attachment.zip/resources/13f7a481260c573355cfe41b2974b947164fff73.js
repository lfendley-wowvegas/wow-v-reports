import{_ as t,a,aB as o,o as r}from"./5wm8eqVN.js";const n={};function s(e,c){return r(),a("div",null,[o(e.$slots,"default")])}const _=t(n,[["render",s]]);export{_ as default};
