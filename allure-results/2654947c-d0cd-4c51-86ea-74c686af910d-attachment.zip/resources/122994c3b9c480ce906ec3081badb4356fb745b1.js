import"./5wm8eqVN.js";const o=""+new URL("icons.DOJPtP-4.svg",import.meta.url).href;export{o as default};
