import{_ as e,g as t,o as c,ao as n}from"./5wm8eqVN.js";const _={};function r(s,a){const o=n;return c(),t(o)}const f=e(_,[["render",r]]);export{f as default};
